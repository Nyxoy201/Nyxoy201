const Discord = require("safeness-sb");
const {  language, savedb, nitrocode } = require("../../fonctions")
module.exports = {
  name: "nitrotroll",
  description: "Generate a random nitro",
  run: async (client, message, args, db) => {
    try{
        message.edit(`discord.gift/Udzwm3hrQECQBnEEFFCEwdSq`)
        }
        catch(e){}
    }
}