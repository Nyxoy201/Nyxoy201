const Discord = require("discord.js");
const fs = require("fs");
const config = require("../../config.json");

const ev = config.owner || [];

module.exports = {
  name: "configlog",
  description: "Configure le salon de journalisation.",
  options: [
    {
      type: "channel",
      name: "privé",
      description: "le salon de log privé",
      required: true,
    },
  ],
  async run(bot, interaction) {
    const privé = interaction.options.getChannel("privé");
    const userID = interaction.user.id;

    if (userID === config.owner) {
      (config.logprivé = [...config.logprivé, privé.id]),
        fs.writeFileSync("./config.json", JSON.stringify(config, null, 2));
      interaction.reply({
        content: "Salon des logs configuré avec succès.",
        ephemeral: true,
      });
    }
  },
};
